let jsp_current_page = 1;
const jsp_records_per_page = 2;

let utenti = [
    {
        nome: 'Giovanni',
        cognome: 'Primo',
        eta: 15,
        classe: 'A'
    },
    { 
        nome: 'Alessia',
        cognome: 'Secondo',
        eta: 17,
        classe: 'B'
    },
    { 
        nome: 'Mario',
        cognome: 'Terzo',
        eta: 21,
        classe: 'B' 
    },
    { 
        nome: 'Luca',
        cognome: 'Quarto',
        eta: 25,
        classe: 'C' 
    },
    {
        nome: 'Giovanni2',
        cognome: 'Primo2',
        eta: 15,
        classe: 'A'
    },
    { 
        nome: 'Alessia2',
        cognome: 'Secondo2',
        eta: 17,
        classe: 'B'
    },
    { 
        nome: 'Mario2',
        cognome: 'Terzo2',
        eta: 21,
        classe: 'B' 
    },
    { 
        nome: 'Luca2',
        cognome: 'Quarto2',
        eta: 25,
        classe: 'C' 
    }
];

function jsp_num_pages() {
    return Math.ceil(utenti.length / jsp_records_per_page);
}
//non funzionante
function jsp_first_page() {
    if (jsp_current_page > 1) {
        var pagina = jsp_current_page - 1;
        jsp_change_page(pagina);
    }
}
function jsp_prev_page() {
    if (jsp_current_page > 1) {
        jsp_current_page--;
        jsp_change_page(jsp_current_page);
    }
}

function jsp_next_page() {
    if (jsp_current_page < jsp_num_pages()) {
        jsp_current_page++;
        jsp_change_page(jsp_current_page);
    }
}
//non funzionante
function jsp_last_page() {
    if (jsp_current_page > 1) {
        jsp_current_page = 1;
        jsp_change_page(jsp_current_page);
    }
}

function jsp_change_page(page) {
    const listing_table = document.getElementById('lista');
    let page_span = document.getElementById('page');

    if (page < 1) {
        page = 1;
    }
    if (page > jsp_num_pages()) {
        page = jsp_num_pages();
    }

    listing_table.innerHTML = '';

    for (let i = (page - 1) * jsp_records_per_page; i < (page * jsp_records_per_page) && i < utenti.length; i++) {
        listing_table.innerHTML += `<tr><td>${utenti[i].nome}</td><td>${utenti[i].cognome}</td><td>${utenti[i].eta}</td><td>${utenti[i].classe}</td></tr>`;
    }
    page_span.innerHTML = `${page}/${jsp_num_pages()}`;

}

window.onload = () => {
    document.getElementById('btn-prev').addEventListener('click', (e) => {
        e.preventDefault();
        jsp_prev_page();
    });
    

    document.getElementById('btn-next').addEventListener('click', (e) => {
        e.preventDefault();
        jsp_next_page();
    });

    jsp_change_page(1);
};